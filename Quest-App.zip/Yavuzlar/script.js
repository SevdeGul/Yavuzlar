function soruYukle() {
    fetch('sorular.json')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP hata: ${response.status}`);
            }
            return response.json();
        })
        .then(questions => {
            console.log(questions)
            window.localStorage.setItem('sorular', JSON.stringify(questions));
            soruGoster();
        })
        .catch(error => {
            console.error("Sorular yüklenirken bir hata oluştu:", error);
        });
}

function soruGoster() {
    var questions = window.localStorage.getItem('sorular')
    if (questions) {
        questions = JSON.parse(questions);
    } else {
        console.log("Sorular localStorage'a yüklenmemiş!");
    }

    const questionList = document.getElementById('soru-listesi');
    questionList.innerHTML = ''; 

    questions.forEach((question, index) => {
        const questionItem = document.createElement('div');
        questionItem.className = 'soru-item';

        const questionText = document.createElement('span');
        questionText.textContent = question.question;

        const editButton = document.createElement('button');
        editButton.textContent = 'Düzenle';
        editButton.onclick = function() {
            duzenle(question.id);
        };

        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Sil';
        deleteButton.onclick = () => {
            soruSil(questions, index);
        };

        const buttonGroup = document.createElement('div');
        buttonGroup.appendChild(editButton);
        buttonGroup.appendChild(deleteButton);

        questionItem.appendChild(questionText);
        questionItem.appendChild(buttonGroup);

        questionList.appendChild(questionItem);
    });
}

function soruSil(questions, index) {
    questions.splice(index, 1);
    soruGoster(questions);
}

function soruEkle(){

}

function duzenle(soruId) {
    window.location.href = "soru_duzenle.html?soruId=" + soruId

}

function getQueryParam(name) {
    const params = new URLSearchParams(window.location.search);
    return params.get(name);
}


function soruGuncelle(soruId, soruText){
    var sorular = window.localStorage.getItem('sorular')
    if (sorular) {
        sorular = JSON.parse(sorular);
    } else {
        console.log("Sorular localStorage'a yüklenmemiş!");
    }

    let found = false;
        sorular.forEach(function(soru) {
            if (soru.id === soruId) {
                soru.question = soruText;
                found = true;
            }
        });
    
        if (found) {
            window.localStorage.setItem('sorular', JSON.stringify(sorular));
            console.log("Soru güncellendi!");
        } else {
            console.log("Belirtilen ID ile soru bulunamadı.");
        }
}
function loadSoru(){

    const soruId = parseInt(getQueryParam('soruId'), 10);

    fetch('sorular.json')
    .then(response => response.json())
    .then(data => {
        const soru = data.find(s => s.id === soruId);
        
        const detayDiv = document.getElementById('soru-detay');
        if (soru) {
            const soruForm = document.createElement('form');
            soruForm.innerHTML = `
                <label for="soru-id">ID:</label>
                <input type="text" id="soru-id" value="${soru.id}" readonly><br>
                <label for="soru-metni">Soru:</label>
                <input type="text" id="soru-metni" value="${soru.question}"><br>
                <button type="button" onclick="soruGuncelle(${soru.id})">Güncelle</button>
                <button type="button" onclick="goBack()">Geri Dön</button>
            `;
            detayDiv.appendChild(soruForm);
        } else {
            detayDiv.innerHTML = `<p>Belirtilen ID'ye sahip soru bulunamadı.</p>`;
        }
    })
    .catch(error => {
        console.error("Sorular yüklenirken bir hata oluştu:", error);
    });
}


function getSoru() {
    const soruId = getQueryParam('soruId');

}


